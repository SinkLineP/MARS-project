export const MenuItems = [
    {
        title: 'Категоріі',
        url: '#home/',
        cName: 'nav-links'
    },
    {
        title: 'Контакти',
        url: '#servises/',
        cName: 'nav-links'
    },
    {
        title: 'Про нас',
        url: '#products /',
        cName: 'nav-links'
    },
    {
        title: 'Авторизація',
        url: '#signin/',
        cName: 'nav-links-1'
    },
    {
        title: 'Реєстрація',
        url: '#signup/',
        cName: 'nav-links-1'
    }
];